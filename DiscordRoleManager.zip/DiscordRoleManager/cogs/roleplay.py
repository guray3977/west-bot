import discord
from discord.ext import commands
from discord import app_commands
from datetime import datetime
import random
from utils.names import generate_random_name

class RoleplayCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    @app_commands.command(name="karakter", description="RP karakter profili oluştur")
    @app_commands.describe(
        name="Karakter adı",
        age="Karakter yaşı",
        occupation="Karakter mesleği/rolü",
        background="Karakter geçmişi (opsiyonel)"
    )
    async def character(
        self, 
        interaction: discord.Interaction, 
        name: str, 
        age: int, 
        occupation: str,
        background: str = None
    ):
        """Create or update character profile"""
        try:
            # Validate age
            if age < 18 or age > 100:
                await interaction.response.send_message("❌ Karakter yaşı 18-100 arasında olmalıdır!", ephemeral=True)
                return
            
            # Create character data
            character_data = {
                "name": name,
                "age": age,
                "occupation": occupation,
                "background": background or "Belirtilmedi",
                "user_id": interaction.user.id,
                "guild_id": interaction.guild.id
            }
            
            # Save character
            self.bot.db.save_character(interaction.user.id, character_data)
            
            # Create embed
            embed = discord.Embed(
                title="🎭 Karakter Profili Oluşturuldu",
                color=discord.Color.blue(),
                timestamp=datetime.now()
            )
            embed.set_thumbnail(url=interaction.user.display_avatar.url)
            embed.add_field(name="👤 Karakter Adı", value=name, inline=True)
            embed.add_field(name="🎂 Yaş", value=str(age), inline=True)
            embed.add_field(name="💼 Meslek/Rol", value=occupation, inline=True)
            embed.add_field(name="📖 Geçmiş", value=background or "Belirtilmedi", inline=False)
            embed.add_field(name="👥 Oyuncu", value=interaction.user.mention, inline=True)
            embed.set_footer(text="Karakter profili başarıyla kaydedildi!")
            
            await interaction.response.send_message(embed=embed)
            
            # Update activity
            self.bot.db.update_activity(interaction.user.id, "character_created")
            
        except Exception as e:
            await interaction.response.send_message(f"❌ Karakter oluşturma başarısız: {e}", ephemeral=True)
    
    @app_commands.command(name="bilgi", description="Kullanıcı bilgilerini ve karakter profilini görüntüle")
    @app_commands.describe(user="Bilgileri görüntülenecek kullanıcı")
    async def info(self, interaction: discord.Interaction, user: discord.Member = None):
        """Display user information and character profile"""
        target_user = user or interaction.user
        
        try:
            # Get character data
            character = self.bot.db.get_character(target_user.id)
            
            # Get activity data
            activity = self.bot.db.get_user_activity(target_user.id)
            
            # Get punishment data
            punishments = self.bot.db.get_punishments(target_user.id)
            active_punishments = [p for p in punishments if p.get("active", False)]
            
            # Create embed
            embed = discord.Embed(
                title="ℹ️ Kullanıcı Bilgileri",
                color=discord.Color.blue(),
                timestamp=datetime.now()
            )
            embed.set_thumbnail(url=target_user.display_avatar.url)
            
            # Basic user info
            embed.add_field(name="👤 Kullanıcı", value=target_user.mention, inline=True)
            embed.add_field(name="🆔 ID", value=str(target_user.id), inline=True)
            embed.add_field(name="📅 Sunucuya Katılım", value=f"<t:{int(target_user.joined_at.timestamp())}:f>", inline=True)
            
            # Character info
            if character:
                embed.add_field(name="🎭 RP Karakter", value=character["name"], inline=True)
                embed.add_field(name="🎂 Yaş", value=str(character["age"]), inline=True)
                embed.add_field(name="💼 Meslek", value=character["occupation"], inline=True)
                if character.get("background") and character["background"] != "Belirtilmedi":
                    embed.add_field(name="📖 Karakter Geçmişi", value=character["background"], inline=False)
            else:
                embed.add_field(name="🎭 RP Karakter", value="Karakter profili yok", inline=False)
            
            # Punishment info
            if active_punishments:
                embed.add_field(
                    name="⚠️ Aktif Cezalar", 
                    value=f"{len(active_punishments)} aktif ceza", 
                    inline=True
                )
            
            embed.add_field(
                name="📊 Toplam Ceza", 
                value=str(len(punishments)), 
                inline=True
            )
            
            # Roles
            roles = [role.mention for role in target_user.roles[1:]]  # Skip @everyone
            if roles:
                roles_text = ", ".join(roles[:10])  # Limit to 10 roles
                if len(target_user.roles) > 11:
                    roles_text += f" +{len(target_user.roles) - 11} daha"
                embed.add_field(name="🎯 Roller", value=roles_text, inline=False)
            
            await interaction.response.send_message(embed=embed)
            
            # Update activity
            self.bot.db.update_activity(interaction.user.id, "info_checked")
            
        except Exception as e:
            await interaction.response.send_message(f"❌ Bilgi görüntüleme başarısız: {e}", ephemeral=True)
    
    @app_commands.command(name="aktiflik", description="Kullanıcı aktiflik istatistiklerini görüntüle")
    @app_commands.describe(user="Aktifliği görüntülenecek kullanıcı")
    async def activity(self, interaction: discord.Interaction, user: discord.Member = None):
        """Display user activity statistics"""
        target_user = user or interaction.user
        
        try:
            # Get activity data
            activity_data = self.bot.db.get_user_activity(target_user.id)
            
            if not activity_data:
                embed = discord.Embed(
                    title="📊 Aktiflik İstatistikleri",
                    description=f"{target_user.mention} için aktiflik verisi bulunamadı.",
                    color=discord.Color.orange()
                )
                await interaction.response.send_message(embed=embed)
                return
            
            # Create embed
            embed = discord.Embed(
                title="📊 Aktiflik İstatistikleri",
                color=discord.Color.green(),
                timestamp=datetime.now()
            )
            embed.set_thumbnail(url=target_user.display_avatar.url)
            embed.add_field(name="👤 Kullanıcı", value=target_user.mention, inline=False)
            
            # Calculate totals
            total_messages = 0
            total_commands = 0
            total_characters = 0
            
            for date, activities in activity_data.items():
                total_messages += activities.get("messages", 0)
                total_commands += activities.get("commands_used", 0)
                total_characters += activities.get("character_created", 0)
            
            embed.add_field(name="💬 Toplam Mesaj", value=str(total_messages), inline=True)
            embed.add_field(name="⚡ Komut Kullanımı", value=str(total_commands), inline=True)
            embed.add_field(name="🎭 Karakter Oluşturma", value=str(total_characters), inline=True)
            
            # Recent activity (last 7 days)
            recent_dates = sorted(activity_data.keys())[-7:]
            if recent_dates:
                recent_activity = []
                for date in recent_dates:
                    activities = activity_data[date]
                    daily_total = sum(activities.values())
                    recent_activity.append(f"**{date}:** {daily_total} aktivite")
                
                embed.add_field(
                    name="📅 Son 7 Gün Aktifliği",
                    value="\n".join(recent_activity) if recent_activity else "Veri yok",
                    inline=False
                )
            
            await interaction.response.send_message(embed=embed)
            
            # Update activity
            self.bot.db.update_activity(interaction.user.id, "activity_checked")
            
        except Exception as e:
            await interaction.response.send_message(f"❌ Aktiflik görüntüleme başarısız: {e}", ephemeral=True)
    
    @app_commands.command(name="isimver", description="Belirtilen role sahip kullanıcıların isimlerini yabancı isimlerle değiştir")
    async def change_names(self, interaction: discord.Interaction):
        """Change nicknames of users with specific role to random foreign names"""
        if not self.bot.config.is_admin(interaction.user):
            await interaction.response.send_message("❌ Bu komutu kullanmak için yeterli yetkiniz yok!", ephemeral=True)
            return
        
        try:
            # Get the target role ID from config
            target_role_id = self.bot.config.get_nickname_role_id()
            target_role = interaction.guild.get_role(target_role_id)
            
            if not target_role:
                await interaction.response.send_message(f"❌ Belirtilen rol (ID: {target_role_id}) bulunamadı!", ephemeral=True)
                return
            
            # Defer the response as this might take a while
            await interaction.response.defer()
            
            changed_users = []
            failed_users = []
            
            # Process each member with the target role
            for member in target_role.members:
                try:
                    # Generate random name
                    new_name = generate_random_name()
                    
                    # Change nickname
                    await member.edit(nick=new_name)
                    changed_users.append(f"{member.mention} → **{new_name}**")
                    
                    # Small delay to avoid rate limits
                    await discord.utils.sleep_until(discord.utils.utcnow() + discord.timedelta(milliseconds=500))
                    
                except Exception as e:
                    failed_users.append(f"{member.mention} (Hata: {str(e)[:50]})")
            
            # Create result embed
            embed = discord.Embed(
                title="🎭 Toplu İsim Değiştirme",
                color=discord.Color.green() if changed_users else discord.Color.red(),
                timestamp=datetime.now()
            )
            
            embed.add_field(name="🎯 Hedef Rol", value=target_role.mention, inline=False)
            
            if changed_users:
                # Split into multiple fields if too many users
                chunks = [changed_users[i:i+10] for i in range(0, len(changed_users), 10)]
                for i, chunk in enumerate(chunks):
                    field_name = f"✅ Başarıyla Değiştirilen ({i+1}/{len(chunks)})" if len(chunks) > 1 else "✅ Başarıyla Değiştirilen"
                    embed.add_field(name=field_name, value="\n".join(chunk), inline=False)
            
            if failed_users:
                # Split into multiple fields if too many failed users
                chunks = [failed_users[i:i+10] for i in range(0, len(failed_users), 10)]
                for i, chunk in enumerate(chunks):
                    field_name = f"❌ Başarısız ({i+1}/{len(chunks)})" if len(chunks) > 1 else "❌ Başarısız"
                    embed.add_field(name=field_name, value="\n".join(chunk), inline=False)
            
            embed.set_footer(text=f"Toplam: {len(changed_users)} başarılı, {len(failed_users)} başarısız")
            
            await interaction.followup.send(embed=embed)
            
            # Log the action
            await self.bot.log_action(
                interaction.guild,
                "Toplu İsim Değiştirme",
                f"{interaction.user.mention} tarafından {target_role.mention} rolündeki {len(changed_users)} kullanıcının ismi değiştirildi.",
                discord.Color.blue()
            )
            
        except Exception as e:
            await interaction.followup.send(f"❌ İsim değiştirme işlemi başarısız: {e}", ephemeral=True)
