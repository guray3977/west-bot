import discord
from discord.ext import commands
from discord import app_commands
from datetime import datetime

class AdminCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    @app_commands.command(name="duyuru", description="Embedli duyuru mesajı gönder")
    @app_commands.describe(
        message="Duyuru mesajı",
        channel="Duyuru gönderilecek kanal (opsiyonel)",
        ping_everyone="Herkesi etiketle (@everyone)"
    )
    async def announcement(
        self, 
        interaction: discord.Interaction, 
        message: str,
        channel: discord.TextChannel = None,
        ping_everyone: bool = False
    ):
        """Send an embedded announcement"""
        if not self.bot.config.is_admin(interaction.user):
            await interaction.response.send_message("❌ Bu komutu kullanmak için yeterli yetkiniz yok!", ephemeral=True)
            return
        
        try:
            target_channel = channel or interaction.channel
            
            # Create announcement embed
            embed = discord.Embed(
                title="📢 Duyuru",
                description=message,
                color=discord.Color.blue(),
                timestamp=datetime.now()
            )
            embed.set_author(
                name=interaction.user.display_name,
                icon_url=interaction.user.display_avatar.url
            )
            embed.set_footer(text=f"Duyuru • {interaction.guild.name}")
            
            # Send announcement
            content = "@everyone" if ping_everyone else None
            announcement_msg = await target_channel.send(content=content, embed=embed)
            
            # Add reaction for acknowledgment
            await announcement_msg.add_reaction("✅")
            
            # Confirm to user
            confirm_embed = discord.Embed(
                title="✅ Duyuru Gönderildi",
                description=f"Duyuru {target_channel.mention} kanalına başarıyla gönderildi.",
                color=discord.Color.green()
            )
            
            await interaction.response.send_message(embed=confirm_embed, ephemeral=True)
            
            # Log the action
            await self.bot.log_action(
                interaction.guild,
                "Duyuru Gönderildi",
                f"{interaction.user.mention} tarafından {target_channel.mention} kanalına duyuru gönderildi.\n"
                f"İçerik: {message[:200]}{'...' if len(message) > 200 else ''}",
                discord.Color.blue()
            )
            
        except Exception as e:
            await interaction.response.send_message(f"❌ Duyuru gönderme başarısız: {e}", ephemeral=True)
    
    @app_commands.command(name="toplanti", description="Toplantı duyurusu gönder")
    @app_commands.describe(
        time="Toplantı zamanı",
        topic="Toplantı konusu (opsiyonel)",
        channel="Duyuru gönderilecek kanal (opsiyonel)"
    )
    async def meeting(
        self, 
        interaction: discord.Interaction, 
        time: str,
        topic: str = None,
        channel: discord.TextChannel = None
    ):
        """Send a meeting announcement"""
        if not self.bot.config.is_admin(interaction.user):
            await interaction.response.send_message("❌ Bu komutu kullanmak için yeterli yetkiniz yok!", ephemeral=True)
            return
        
        try:
            target_channel = channel or interaction.channel
            
            # Create meeting embed
            embed = discord.Embed(
                title="🔔 Toplantı Duyurusu",
                color=discord.Color.orange(),
                timestamp=datetime.now()
            )
            embed.add_field(name="⏰ Zaman", value=time, inline=True)
            embed.add_field(name="👤 Organizatör", value=interaction.user.mention, inline=True)
            
            if topic:
                embed.add_field(name="📋 Konu", value=topic, inline=False)
            else:
                embed.add_field(name="📋 Konu", value="Genel toplantı", inline=False)
            
            embed.add_field(
                name="📌 Önemli",
                value="Lütfen zamanında katılın. Geç kalanlara bilgi verilmeyecektir.",
                inline=False
            )
            
            embed.set_author(
                name="Toplantı Bildirimi",
                icon_url=interaction.guild.icon.url if interaction.guild.icon else None
            )
            embed.set_footer(text=f"Toplantı Duyurusu • {interaction.guild.name}")
            
            # Send meeting announcement with @everyone ping
            meeting_msg = await target_channel.send(content="@everyone", embed=embed)
            
            # Add reactions for attendance
            await meeting_msg.add_reaction("✅")  # Will attend
            await meeting_msg.add_reaction("❌")  # Won't attend
            await meeting_msg.add_reaction("❓")  # Maybe
            
            # Confirm to user
            confirm_embed = discord.Embed(
                title="✅ Toplantı Duyurusu Gönderildi",
                description=f"Toplantı duyurusu {target_channel.mention} kanalına başarıyla gönderildi.",
                color=discord.Color.green()
            )
            
            await interaction.response.send_message(embed=confirm_embed, ephemeral=True)
            
            # Log the action
            await self.bot.log_action(
                interaction.guild,
                "Toplantı Duyurusu",
                f"{interaction.user.mention} tarafından toplantı duyurusu gönderildi.\n"
                f"Zaman: {time}\nKanal: {target_channel.mention}",
                discord.Color.orange()
            )
            
        except Exception as e:
            await interaction.response.send_message(f"❌ Toplantı duyurusu gönderme başarısız: {e}", ephemeral=True)
    
    @app_commands.command(name="ayarla", description="Bot ayarlarını yapılandır")
    @app_commands.describe(
        setting="Ayar türü",
        value="Ayar değeri (kanal/rol ID'si)"
    )
    @app_commands.choices(setting=[
        app_commands.Choice(name="Log Kanalı", value="log_channel"),
        app_commands.Choice(name="Otomatik Rol", value="auto_role"),
        app_commands.Choice(name="Admin Rolü Ekle", value="add_admin_role"),
        app_commands.Choice(name="Moderatör Rolü Ekle", value="add_mod_role")
    ])
    async def configure(self, interaction: discord.Interaction, setting: str, value: str):
        """Configure bot settings"""
        if not self.bot.config.is_admin(interaction.user):
            await interaction.response.send_message("❌ Bu komutu kullanmak için yeterli yetkiniz yok!", ephemeral=True)
            return
        
        try:
            # Parse value as ID
            try:
                setting_id = int(value)
            except ValueError:
                await interaction.response.send_message("❌ Geçersiz ID! Lütfen geçerli bir sayı girin.", ephemeral=True)
                return
            
            success_message = ""
            
            if setting == "log_channel":
                channel = interaction.guild.get_channel(setting_id)
                if not channel:
                    await interaction.response.send_message("❌ Belirtilen kanal bulunamadı!", ephemeral=True)
                    return
                
                self.bot.config.set_log_channel(interaction.guild.id, setting_id)
                success_message = f"Log kanalı {channel.mention} olarak ayarlandı."
                
            elif setting == "auto_role":
                role = interaction.guild.get_role(setting_id)
                if not role:
                    await interaction.response.send_message("❌ Belirtilen rol bulunamadı!", ephemeral=True)
                    return
                
                self.bot.config.set_auto_role(interaction.guild.id, setting_id)
                success_message = f"Otomatik rol {role.mention} olarak ayarlandı."
                
            elif setting == "add_admin_role":
                role = interaction.guild.get_role(setting_id)
                if not role:
                    await interaction.response.send_message("❌ Belirtilen rol bulunamadı!", ephemeral=True)
                    return
                
                self.bot.config.add_admin_role(interaction.guild.id, setting_id)
                success_message = f"Admin rolü {role.mention} eklendi."
                
            elif setting == "add_mod_role":
                role = interaction.guild.get_role(setting_id)
                if not role:
                    await interaction.response.send_message("❌ Belirtilen rol bulunamadı!", ephemeral=True)
                    return
                
                self.bot.config.add_moderator_role(interaction.guild.id, setting_id)
                success_message = f"Moderatör rolü {role.mention} eklendi."
            
            # Create success embed
            embed = discord.Embed(
                title="⚙️ Ayar Güncellendi",
                description=success_message,
                color=discord.Color.green(),
                timestamp=datetime.now()
            )
            
            await interaction.response.send_message(embed=embed)
            
            # Log the action
            await self.bot.log_action(
                interaction.guild,
                "Bot Ayarı Güncellendi",
                f"{interaction.user.mention} tarafından bot ayarı güncellendi: {success_message}",
                discord.Color.blue()
            )
            
        except Exception as e:
            await interaction.response.send_message(f"❌ Ayar güncelleme başarısız: {e}", ephemeral=True)
    
    @app_commands.command(name="temizle", description="Belirtilen sayıda mesajı sil")
    @app_commands.describe(
        amount="Silinecek mesaj sayısı (1-100)",
        user="Belirli bir kullanıcının mesajlarını sil (opsiyonel)"
    )
    async def purge(
        self, 
        interaction: discord.Interaction, 
        amount: int,
        user: discord.Member = None
    ):
        """Delete specified number of messages"""
        if not self.bot.config.is_moderator(interaction.user):
            await interaction.response.send_message("❌ Bu komutu kullanmak için yeterli yetkiniz yok!", ephemeral=True)
            return
        
        if amount < 1 or amount > 100:
            await interaction.response.send_message("❌ Mesaj sayısı 1-100 arasında olmalıdır!", ephemeral=True)
            return
        
        try:
            # Defer response as this might take time
            await interaction.response.defer(ephemeral=True)
            
            def check_user(message):
                if user:
                    return message.author == user
                return True
            
            # Delete messages
            deleted = await interaction.channel.purge(limit=amount, check=check_user)
            
            # Create result embed
            embed = discord.Embed(
                title="🧹 Mesajlar Silindi",
                color=discord.Color.green(),
                timestamp=datetime.now()
            )
            embed.add_field(name="📊 Silinen Mesaj", value=str(len(deleted)), inline=True)
            embed.add_field(name="👤 Moderatör", value=interaction.user.mention, inline=True)
            embed.add_field(name="📍 Kanal", value=interaction.channel.mention, inline=True)
            
            if user:
                embed.add_field(name="🎯 Hedef Kullanıcı", value=user.mention, inline=True)
            
            await interaction.followup.send(embed=embed)
            
            # Log the action
            await self.bot.log_action(
                interaction.guild,
                "Mesajlar Silindi",
                f"{interaction.user.mention} tarafından {interaction.channel.mention} kanalında "
                f"{len(deleted)} mesaj silindi." + (f"\nHedef kullanıcı: {user.mention}" if user else ""),
                discord.Color.orange()
            )
            
        except Exception as e:
            await interaction.followup.send(f"❌ Mesaj silme başarısız: {e}")
