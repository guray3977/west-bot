import discord
from discord.ext import commands
from discord import app_commands
from datetime import datetime
import uuid

class EventsCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    @app_commands.command(name="olay", description="Yeni bir RP olayı oluştur")
    @app_commands.describe(
        title="Olay başlığı",
        participants="Katılımcı sayısı",
        location="Olay lokasyonu",
        description="Olay açıklaması (opsiyonel)"
    )
    async def create_event(
        self, 
        interaction: discord.Interaction, 
        title: str, 
        participants: int,
        location: str,
        description: str = None
    ):
        """Create a new RP event"""
        try:
            # Validate participants
            if participants < 1 or participants > 50:
                await interaction.response.send_message("❌ Katılımcı sayısı 1-50 arasında olmalıdır!", ephemeral=True)
                return
            
            # Generate unique event ID
            event_id = str(uuid.uuid4())[:8]
            
            # Create event data
            event_data = {
                "id": event_id,
                "title": title,
                "participants": participants,
                "location": location,
                "description": description or "Açıklama yok",
                "creator": interaction.user.id,
                "guild_id": interaction.guild.id,
                "status": "active",
                "joined_users": []
            }
            
            # Save event
            self.bot.db.save_event(event_id, event_data)
            
            # Create embed
            embed = discord.Embed(
                title="🎯 Yeni Olay Oluşturuldu",
                color=discord.Color.gold(),
                timestamp=datetime.now()
            )
            embed.add_field(name="📋 Olay ID", value=f"`{event_id}`", inline=True)
            embed.add_field(name="🎭 Başlık", value=title, inline=True)
            embed.add_field(name="👥 Katılımcı Sayısı", value=f"{participants} kişi", inline=True)
            embed.add_field(name="📍 Lokasyon", value=location, inline=True)
            embed.add_field(name="👤 Organizatör", value=interaction.user.mention, inline=True)
            embed.add_field(name="⏰ Oluşturulma", value=f"<t:{int(datetime.now().timestamp())}:f>", inline=True)
            
            if description:
                embed.add_field(name="📖 Açıklama", value=description, inline=False)
            
            embed.set_footer(text=f"Olaya katılmak için: /katil {event_id}")
            
            await interaction.response.send_message(embed=embed)
            
            # Update activity
            self.bot.db.update_activity(interaction.user.id, "event_created")
            
            # Log the action
            await self.bot.log_action(
                interaction.guild,
                "Olay Oluşturuldu",
                f"{interaction.user.mention} tarafından yeni olay oluşturuldu: **{title}**\n"
                f"Lokasyon: {location}\nKatılımcı: {participants} kişi",
                discord.Color.gold()
            )
            
        except Exception as e:
            await interaction.response.send_message(f"❌ Olay oluşturma başarısız: {e}", ephemeral=True)
    
    @app_commands.command(name="olaylar", description="Aktif olayları listele")
    async def list_events(self, interaction: discord.Interaction):
        """List all active events"""
        try:
            all_events = self.bot.db.get_all_events()
            
            # Filter active events for this guild
            active_events = []
            for event_id, event_data in all_events.items():
                if (event_data.get("guild_id") == interaction.guild.id and 
                    event_data.get("status") == "active"):
                    active_events.append((event_id, event_data))
            
            if not active_events:
                embed = discord.Embed(
                    title="🎯 Aktif Olaylar",
                    description="Şu anda aktif bir olay bulunmuyor.",
                    color=discord.Color.orange()
                )
                await interaction.response.send_message(embed=embed)
                return
            
            # Create embed
            embed = discord.Embed(
                title="🎯 Aktif Olaylar",
                description=f"Sunucuda {len(active_events)} aktif olay bulunuyor:",
                color=discord.Color.blue(),
                timestamp=datetime.now()
            )
            
            for event_id, event_data in active_events[:10]:  # Limit to 10 events
                creator = self.bot.get_user(event_data.get("creator", 0))
                creator_name = creator.display_name if creator else "Bilinmiyor"
                
                joined_count = len(event_data.get("joined_users", []))
                total_participants = event_data.get("participants", 0)
                
                event_info = (
                    f"**Lokasyon:** {event_data.get('location', 'Belirtilmedi')}\n"
                    f"**Organizatör:** {creator_name}\n"
                    f"**Katılımcı:** {joined_count}/{total_participants}\n"
                    f"**ID:** `{event_id}`"
                )
                
                if event_data.get("description") and event_data["description"] != "Açıklama yok":
                    event_info += f"\n**Açıklama:** {event_data['description'][:100]}..."
                
                embed.add_field(
                    name=f"🎭 {event_data.get('title', 'Başlıksız Olay')}",
                    value=event_info,
                    inline=False
                )
            
            if len(active_events) > 10:
                embed.set_footer(text=f"Ve {len(active_events) - 10} olay daha...")
            
            await interaction.response.send_message(embed=embed)
            
            # Update activity
            self.bot.db.update_activity(interaction.user.id, "events_viewed")
            
        except Exception as e:
            await interaction.response.send_message(f"❌ Olay listesi görüntüleme başarısız: {e}", ephemeral=True)
    
    @app_commands.command(name="katil", description="Bir olaya katıl")
    @app_commands.describe(event_id="Katılınacak olay ID'si")
    async def join_event(self, interaction: discord.Interaction, event_id: str):
        """Join an event"""
        try:
            # Get event data
            event_data = self.bot.db.get_event(event_id)
            
            if not event_data:
                await interaction.response.send_message("❌ Belirtilen olay bulunamadı!", ephemeral=True)
                return
            
            if event_data.get("guild_id") != interaction.guild.id:
                await interaction.response.send_message("❌ Bu olay bu sunucuya ait değil!", ephemeral=True)
                return
            
            if event_data.get("status") != "active":
                await interaction.response.send_message("❌ Bu olay artık aktif değil!", ephemeral=True)
                return
            
            # Check if user already joined
            joined_users = event_data.get("joined_users", [])
            if interaction.user.id in joined_users:
                await interaction.response.send_message("❌ Bu olaya zaten katıldınız!", ephemeral=True)
                return
            
            # Check if event is full
            max_participants = event_data.get("participants", 0)
            if len(joined_users) >= max_participants:
                await interaction.response.send_message("❌ Bu olay dolu! Katılımcı sınırına ulaşılmış.", ephemeral=True)
                return
            
            # Add user to event
            joined_users.append(interaction.user.id)
            event_data["joined_users"] = joined_users
            self.bot.db.save_event(event_id, event_data)
            
            # Create embed
            embed = discord.Embed(
                title="✅ Olaya Katıldınız",
                color=discord.Color.green(),
                timestamp=datetime.now()
            )
            embed.add_field(name="🎭 Olay", value=event_data.get("title", "Başlıksız"), inline=True)
            embed.add_field(name="📍 Lokasyon", value=event_data.get("location", "Belirtilmedi"), inline=True)
            embed.add_field(name="👥 Katılımcı Durumu", value=f"{len(joined_users)}/{max_participants}", inline=True)
            
            await interaction.response.send_message(embed=embed)
            
            # Update activity
            self.bot.db.update_activity(interaction.user.id, "event_joined")
            
            # Notify if event is now full
            if len(joined_users) >= max_participants:
                creator = self.bot.get_user(event_data.get("creator", 0))
                if creator:
                    try:
                        full_embed = discord.Embed(
                            title="🎯 Olay Doldu",
                            description=f"Oluşturduğunuz **{event_data.get('title')}** olayı katılımcı sınırına ulaştı!",
                            color=discord.Color.gold()
                        )
                        await creator.send(embed=full_embed)
                    except:
                        pass  # User has DMs disabled
            
        except Exception as e:
            await interaction.response.send_message(f"❌ Olaya katılma başarısız: {e}", ephemeral=True)
    
    @app_commands.command(name="olaybitir", description="Bir olayı sonlandır")
    @app_commands.describe(event_id="Sonlandırılacak olay ID'si")
    async def end_event(self, interaction: discord.Interaction, event_id: str):
        """End an event"""
        try:
            # Get event data
            event_data = self.bot.db.get_event(event_id)
            
            if not event_data:
                await interaction.response.send_message("❌ Belirtilen olay bulunamadı!", ephemeral=True)
                return
            
            if event_data.get("guild_id") != interaction.guild.id:
                await interaction.response.send_message("❌ Bu olay bu sunucuya ait değil!", ephemeral=True)
                return
            
            # Check permissions (creator or admin)
            if (event_data.get("creator") != interaction.user.id and 
                not self.bot.config.is_admin(interaction.user)):
                await interaction.response.send_message("❌ Bu olayı sadece oluşturan kişi veya yöneticiler sonlandırabilir!", ephemeral=True)
                return
            
            # End the event
            event_data["status"] = "ended"
            event_data["ended_at"] = datetime.now().isoformat()
            event_data["ended_by"] = interaction.user.id
            self.bot.db.save_event(event_id, event_data)
            
            # Create embed
            embed = discord.Embed(
                title="🏁 Olay Sonlandırıldı",
                color=discord.Color.red(),
                timestamp=datetime.now()
            )
            embed.add_field(name="🎭 Olay", value=event_data.get("title", "Başlıksız"), inline=True)
            embed.add_field(name="📍 Lokasyon", value=event_data.get("location", "Belirtilmedi"), inline=True)
            embed.add_field(name="👥 Katılımcı", value=f"{len(event_data.get('joined_users', []))}/{event_data.get('participants', 0)}", inline=True)
            embed.add_field(name="⏰ Sonlandıran", value=interaction.user.mention, inline=True)
            
            await interaction.response.send_message(embed=embed)
            
            # Log the action
            await self.bot.log_action(
                interaction.guild,
                "Olay Sonlandırıldı",
                f"{interaction.user.mention} tarafından **{event_data.get('title')}** olayı sonlandırıldı.",
                discord.Color.red()
            )
            
        except Exception as e:
            await interaction.response.send_message(f"❌ Olay sonlandırma başarısız: {e}", ephemeral=True)
