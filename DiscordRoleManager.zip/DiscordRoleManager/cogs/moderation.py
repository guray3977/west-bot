import discord
from discord.ext import commands
from discord import app_commands
from datetime import datetime, timedelta
import asyncio
from utils.moderation import parse_duration, format_duration

class ModerationCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.muted_users = {}  # Store muted users with expiry times
    
    async def cog_load(self):
        """Start background task for unmuting users"""
        self.bot.loop.create_task(self.check_muted_users())
    
    async def check_muted_users(self):
        """Background task to check and unmute users"""
        while not self.bot.is_closed():
            try:
                current_time = datetime.now()
                users_to_unmute = []
                
                for user_id, mute_data in self.muted_users.items():
                    if current_time >= mute_data['expires_at']:
                        users_to_unmute.append(user_id)
                
                for user_id in users_to_unmute:
                    mute_data = self.muted_users[user_id]
                    guild = self.bot.get_guild(mute_data['guild_id'])
                    if guild:
                        member = guild.get_member(user_id)
                        if member:
                            # Remove muted role or timeout
                            try:
                                await member.timeout(None)
                                
                                # Log unmute
                                await self.bot.log_action(
                                    guild,
                                    "Susturma Kaldırıldı",
                                    f"{member.mention} otomatik olarak susturmadan çıkarıldı.",
                                    discord.Color.green()
                                )
                            except Exception as e:
                                print(f"Error unmuting user {user_id}: {e}")
                    
                    del self.muted_users[user_id]
                
                await asyncio.sleep(60)  # Check every minute
            except Exception as e:
                print(f"Error in check_muted_users: {e}")
                await asyncio.sleep(60)
    
    @app_commands.command(name="ban", description="Bir kullanıcıyı sunucudan yasakla")
    @app_commands.describe(
        user="Yasaklanacak kullanıcı",
        reason="Yasaklama sebebi",
        delete_days="Silinecek mesaj günü (0-7)"
    )
    async def ban(
        self, 
        interaction: discord.Interaction, 
        user: discord.Member, 
        reason: str = "Sebep belirtilmedi",
        delete_days: int = 0
    ):
        """Ban a user from the server"""
        if not self.bot.config.is_moderator(interaction.user):
            await interaction.response.send_message("❌ Bu komutu kullanmak için yeterli yetkiniz yok!", ephemeral=True)
            return
        
        try:
            # Add punishment to database
            self.bot.db.add_punishment(user.id, {
                "type": "ban",
                "reason": reason,
                "moderator": interaction.user.id,
                "guild_id": interaction.guild.id,
                "active": True
            })
            
            # Ban the user
            await user.ban(reason=reason, delete_message_days=delete_days)
            
            # Create embed
            embed = discord.Embed(
                title="🔨 Kullanıcı Yasaklandı",
                color=discord.Color.red(),
                timestamp=datetime.now()
            )
            embed.add_field(name="Kullanıcı", value=f"{user.mention} ({user})", inline=False)
            embed.add_field(name="Moderatör", value=interaction.user.mention, inline=True)
            embed.add_field(name="Sebep", value=reason, inline=True)
            embed.add_field(name="Silinen Mesaj Günü", value=str(delete_days), inline=True)
            
            await interaction.response.send_message(embed=embed)
            
            # Log the action
            await self.bot.log_action(
                interaction.guild,
                "Kullanıcı Yasaklandı",
                f"{user.mention} ({user}) {interaction.user.mention} tarafından yasaklandı.\n"
                f"Sebep: {reason}",
                discord.Color.red()
            )
            
        except Exception as e:
            await interaction.response.send_message(f"❌ Yasaklama işlemi başarısız: {e}", ephemeral=True)
    
    @app_commands.command(name="kick", description="Bir kullanıcıyı sunucudan at")
    @app_commands.describe(
        user="Atılacak kullanıcı",
        reason="Atma sebebi"
    )
    async def kick(self, interaction: discord.Interaction, user: discord.Member, reason: str = "Sebep belirtilmedi"):
        """Kick a user from the server"""
        if not self.bot.config.is_moderator(interaction.user):
            await interaction.response.send_message("❌ Bu komutu kullanmak için yeterli yetkiniz yok!", ephemeral=True)
            return
        
        try:
            # Add punishment to database
            self.bot.db.add_punishment(user.id, {
                "type": "kick",
                "reason": reason,
                "moderator": interaction.user.id,
                "guild_id": interaction.guild.id,
                "active": False
            })
            
            # Kick the user
            await user.kick(reason=reason)
            
            # Create embed
            embed = discord.Embed(
                title="👢 Kullanıcı Atıldı",
                color=discord.Color.orange(),
                timestamp=datetime.now()
            )
            embed.add_field(name="Kullanıcı", value=f"{user.mention} ({user})", inline=False)
            embed.add_field(name="Moderatör", value=interaction.user.mention, inline=True)
            embed.add_field(name="Sebep", value=reason, inline=True)
            
            await interaction.response.send_message(embed=embed)
            
            # Log the action
            await self.bot.log_action(
                interaction.guild,
                "Kullanıcı Atıldı",
                f"{user.mention} ({user}) {interaction.user.mention} tarafından atıldı.\n"
                f"Sebep: {reason}",
                discord.Color.orange()
            )
            
        except Exception as e:
            await interaction.response.send_message(f"❌ Atma işlemi başarısız: {e}", ephemeral=True)
    
    @app_commands.command(name="mute", description="Bir kullanıcıyı sustur")
    @app_commands.describe(
        user="Susturulacak kullanıcı",
        duration="Susturma süresi (örn: 10m, 1h, 1d)",
        reason="Susturma sebebi"
    )
    async def mute(
        self, 
        interaction: discord.Interaction, 
        user: discord.Member, 
        duration: str = "10m",
        reason: str = "Sebep belirtilmedi"
    ):
        """Mute a user"""
        if not self.bot.config.is_moderator(interaction.user):
            await interaction.response.send_message("❌ Bu komutu kullanmak için yeterli yetkiniz yok!", ephemeral=True)
            return
        
        try:
            # Parse duration
            duration_seconds = parse_duration(duration)
            expires_at = datetime.now() + timedelta(seconds=duration_seconds)
            
            # Add punishment to database
            self.bot.db.add_punishment(user.id, {
                "type": "mute",
                "reason": reason,
                "duration": duration_seconds,
                "moderator": interaction.user.id,
                "guild_id": interaction.guild.id,
                "expires_at": expires_at.isoformat(),
                "active": True
            })
            
            # Timeout the user
            await user.timeout(expires_at, reason=reason)
            
            # Store muted user info
            self.muted_users[user.id] = {
                "expires_at": expires_at,
                "guild_id": interaction.guild.id
            }
            
            # Create embed
            embed = discord.Embed(
                title="🔇 Kullanıcı Susturuldu",
                color=discord.Color.red(),
                timestamp=datetime.now()
            )
            embed.add_field(name="Kullanıcı", value=f"{user.mention} ({user})", inline=False)
            embed.add_field(name="Moderatör", value=interaction.user.mention, inline=True)
            embed.add_field(name="Süre", value=format_duration(duration_seconds), inline=True)
            embed.add_field(name="Sebep", value=reason, inline=False)
            embed.add_field(name="Bitiş Zamanı", value=f"<t:{int(expires_at.timestamp())}:F>", inline=False)
            
            await interaction.response.send_message(embed=embed)
            
            # Log the action
            await self.bot.log_action(
                interaction.guild,
                "Kullanıcı Susturuldu",
                f"{user.mention} ({user}) {interaction.user.mention} tarafından susturuldu.\n"
                f"Sebep: {reason}\nSüre: {format_duration(duration_seconds)}",
                discord.Color.red()
            )
            
        except Exception as e:
            await interaction.response.send_message(f"❌ Susturma işlemi başarısız: {e}", ephemeral=True)
    
    @app_commands.command(name="unmute", description="Bir kullanıcının susturmasını kaldır")
    @app_commands.describe(
        user="Susturması kaldırılacak kullanıcı"
    )
    async def unmute(self, interaction: discord.Interaction, user: discord.Member):
        """Unmute a user"""
        if not self.bot.config.is_moderator(interaction.user):
            await interaction.response.send_message("❌ Bu komutu kullanmak için yeterli yetkiniz yok!", ephemeral=True)
            return
        
        try:
            # Remove timeout
            await user.timeout(None)
            
            # Remove from muted users if present
            if user.id in self.muted_users:
                del self.muted_users[user.id]
            
            # Create embed
            embed = discord.Embed(
                title="🔊 Susturma Kaldırıldı",
                color=discord.Color.green(),
                timestamp=datetime.now()
            )
            embed.add_field(name="Kullanıcı", value=f"{user.mention} ({user})", inline=False)
            embed.add_field(name="Moderatör", value=interaction.user.mention, inline=True)
            
            await interaction.response.send_message(embed=embed)
            
            # Log the action
            await self.bot.log_action(
                interaction.guild,
                "Susturma Kaldırıldı",
                f"{user.mention} ({user}) susturmadan {interaction.user.mention} tarafından çıkarıldı.",
                discord.Color.green()
            )
            
        except Exception as e:
            await interaction.response.send_message(f"❌ Susturma kaldırma işlemi başarısız: {e}", ephemeral=True)
    
    @app_commands.command(name="ceza", description="Bir kullanıcıya ceza ver")
    @app_commands.describe(
        user="Ceza verilecek kullanıcı",
        reason="Ceza sebebi",
        duration="Ceza süresi (opsiyonel)"
    )
    async def punishment(
        self, 
        interaction: discord.Interaction, 
        user: discord.Member, 
        reason: str,
        duration: str = None
    ):
        """Give a punishment to a user"""
        if not self.bot.config.is_admin(interaction.user):
            await interaction.response.send_message("❌ Bu komutu kullanmak için yeterli yetkiniz yok!", ephemeral=True)
            return
        
        try:
            # Add punishment to database
            punishment_data = {
                "type": "warning",
                "reason": reason,
                "moderator": interaction.user.id,
                "guild_id": interaction.guild.id,
                "active": True
            }
            
            if duration:
                duration_seconds = parse_duration(duration)
                expires_at = datetime.now() + timedelta(seconds=duration_seconds)
                punishment_data["duration"] = duration_seconds
                punishment_data["expires_at"] = expires_at.isoformat()
            
            self.bot.db.add_punishment(user.id, punishment_data)
            
            # Create embed
            embed = discord.Embed(
                title="⚠️ Ceza Verildi",
                color=discord.Color.red(),
                timestamp=datetime.now()
            )
            embed.add_field(name="Kullanıcı", value=f"{user.mention} ({user})", inline=False)
            embed.add_field(name="Yetkili", value=interaction.user.mention, inline=True)
            embed.add_field(name="Sebep", value=reason, inline=False)
            
            if duration:
                embed.add_field(name="Süre", value=format_duration(duration_seconds), inline=True)
            
            await interaction.response.send_message(embed=embed)
            
            # Log the action
            await self.bot.log_action(
                interaction.guild,
                "Ceza Verildi",
                f"{user.mention} ({user}) {interaction.user.mention} tarafından cezalandırıldı.\n"
                f"Sebep: {reason}" + (f"\nSüre: {format_duration(duration_seconds)}" if duration else ""),
                discord.Color.red()
            )
            
            # Send DM to user
            try:
                dm_embed = discord.Embed(
                    title="⚠️ Ceza Aldınız",
                    description=f"**{interaction.guild.name}** sunucusunda ceza aldınız.",
                    color=discord.Color.red()
                )
                dm_embed.add_field(name="Sebep", value=reason, inline=False)
                if duration:
                    dm_embed.add_field(name="Süre", value=format_duration(duration_seconds), inline=False)
                
                await user.send(embed=dm_embed)
            except:
                pass  # User has DMs disabled
            
        except Exception as e:
            await interaction.response.send_message(f"❌ Ceza verme işlemi başarısız: {e}", ephemeral=True)
    
    @app_commands.command(name="cezalar", description="Bir kullanıcının ceza geçmişini görüntüle")
    @app_commands.describe(user="Ceza geçmişi görüntülenecek kullanıcı")
    async def punishments(self, interaction: discord.Interaction, user: discord.Member):
        """View punishment history of a user"""
        if not self.bot.config.is_moderator(interaction.user):
            await interaction.response.send_message("❌ Bu komutu kullanmak için yeterli yetkiniz yok!", ephemeral=True)
            return
        
        try:
            punishments = self.bot.db.get_punishments(user.id)
            
            if not punishments:
                embed = discord.Embed(
                    title="📄 Ceza Geçmişi",
                    description=f"{user.mention} kullanıcısının herhangi bir ceza kaydı bulunmuyor.",
                    color=discord.Color.green()
                )
                await interaction.response.send_message(embed=embed)
                return
            
            embed = discord.Embed(
                title="📄 Ceza Geçmişi",
                description=f"{user.mention} kullanıcısının ceza geçmişi:",
                color=discord.Color.orange()
            )
            
            for i, punishment in enumerate(punishments[-10:], 1):  # Show last 10 punishments
                moderator = self.bot.get_user(punishment.get("moderator", 0))
                moderator_name = moderator.display_name if moderator else "Bilinmiyor"
                
                punishment_type = punishment.get("type", "warning").title()
                reason = punishment.get("reason", "Sebep belirtilmedi")
                timestamp = punishment.get("timestamp", "")
                
                if timestamp:
                    try:
                        dt = datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
                        time_str = f"<t:{int(dt.timestamp())}:f>"
                    except:
                        time_str = "Bilinmiyor"
                else:
                    time_str = "Bilinmiyor"
                
                embed.add_field(
                    name=f"{i}. {punishment_type}",
                    value=f"**Sebep:** {reason}\n**Yetkili:** {moderator_name}\n**Tarih:** {time_str}",
                    inline=False
                )
            
            embed.set_footer(text=f"Toplam {len(punishments)} ceza kaydı")
            
            await interaction.response.send_message(embed=embed)
            
        except Exception as e:
            await interaction.response.send_message(f"❌ Ceza geçmişi görüntüleme başarısız: {e}", ephemeral=True)
