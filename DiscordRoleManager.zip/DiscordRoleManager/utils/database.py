import json
import os
from datetime import datetime
from typing import Dict, List, Optional, Any

class Database:
    def __init__(self):
        self.data_dir = "data"
        self.ensure_data_directory()
        
        # Initialize data files
        self.characters_file = os.path.join(self.data_dir, "characters.json")
        self.punishments_file = os.path.join(self.data_dir, "punishments.json")
        self.events_file = os.path.join(self.data_dir, "events.json")
        self.activity_file = os.path.join(self.data_dir, "activity.json")
        
        # Load data
        self.characters = self.load_json(self.characters_file, {})
        self.punishments = self.load_json(self.punishments_file, {})
        self.events = self.load_json(self.events_file, {})
        self.activity = self.load_json(self.activity_file, {})
    
    def ensure_data_directory(self):
        """Ensure data directory exists"""
        os.makedirs(self.data_dir, exist_ok=True)
    
    def load_json(self, filepath: str, default: Any) -> Any:
        """Load JSON from file with default fallback"""
        try:
            if os.path.exists(filepath):
                with open(filepath, 'r', encoding='utf-8') as f:
                    return json.load(f)
            else:
                self.save_json(filepath, default)
                return default
        except Exception as e:
            print(f"Error loading {filepath}: {e}")
            return default
    
    def save_json(self, filepath: str, data: Any):
        """Save data to JSON file"""
        try:
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
        except Exception as e:
            print(f"Error saving {filepath}: {e}")
    
    # Character management
    def save_character(self, user_id: int, character_data: Dict):
        """Save character data for a user"""
        self.characters[str(user_id)] = {
            **character_data,
            "created_at": datetime.now().isoformat(),
            "updated_at": datetime.now().isoformat()
        }
        self.save_json(self.characters_file, self.characters)
    
    def get_character(self, user_id: int) -> Optional[Dict]:
        """Get character data for a user"""
        return self.characters.get(str(user_id))
    
    def delete_character(self, user_id: int):
        """Delete character data for a user"""
        if str(user_id) in self.characters:
            del self.characters[str(user_id)]
            self.save_json(self.characters_file, self.characters)
    
    # Punishment management
    def add_punishment(self, user_id: int, punishment_data: Dict):
        """Add punishment record for a user"""
        user_id_str = str(user_id)
        if user_id_str not in self.punishments:
            self.punishments[user_id_str] = []
        
        punishment_data["timestamp"] = datetime.now().isoformat()
        punishment_data["id"] = len(self.punishments[user_id_str]) + 1
        
        self.punishments[user_id_str].append(punishment_data)
        self.save_json(self.punishments_file, self.punishments)
    
    def get_punishments(self, user_id: int) -> List[Dict]:
        """Get punishment history for a user"""
        return self.punishments.get(str(user_id), [])
    
    def get_active_punishments(self, user_id: int) -> List[Dict]:
        """Get active punishments for a user"""
        punishments = self.get_punishments(user_id)
        active = []
        
        for punishment in punishments:
            if punishment.get("active", True):
                active.append(punishment)
        
        return active
    
    # Event management
    def save_event(self, event_id: str, event_data: Dict):
        """Save event data"""
        self.events[event_id] = {
            **event_data,
            "created_at": datetime.now().isoformat(),
            "updated_at": datetime.now().isoformat()
        }
        self.save_json(self.events_file, self.events)
    
    def get_event(self, event_id: str) -> Optional[Dict]:
        """Get event data"""
        return self.events.get(event_id)
    
    def get_all_events(self) -> Dict:
        """Get all events"""
        return self.events
    
    def delete_event(self, event_id: str):
        """Delete event"""
        if event_id in self.events:
            del self.events[event_id]
            self.save_json(self.events_file, self.events)
    
    # Activity tracking
    def update_activity(self, user_id: int, activity_type: str, amount: int = 1):
        """Update user activity"""
        user_id_str = str(user_id)
        today = datetime.now().date().isoformat()
        
        if user_id_str not in self.activity:
            self.activity[user_id_str] = {}
        
        if today not in self.activity[user_id_str]:
            self.activity[user_id_str][today] = {}
        
        if activity_type not in self.activity[user_id_str][today]:
            self.activity[user_id_str][today][activity_type] = 0
        
        self.activity[user_id_str][today][activity_type] += amount
        self.save_json(self.activity_file, self.activity)
    
    def get_user_activity(self, user_id: int, days: int = 7) -> Dict:
        """Get user activity for specified days"""
        user_id_str = str(user_id)
        if user_id_str not in self.activity:
            return {}
        
        # Get recent activity (simple implementation)
        return self.activity[user_id_str]
