import random

# Foreign names and surnames for automatic nickname generation
FIRST_NAMES = [
    # English names
    "Alexander", "James", "William", "Benjamin", "Michael", "David", "Robert", "John",
    "Christopher", "Matthew", "Daniel", "Anthony", "Mark", "Paul", "Steven", "Kenneth",
    "Emma", "Olivia", "Sophia", "Isabella", "Mia", "Charlotte", "Amelia", "Harper",
    "Evelyn", "Abigail", "Emily", "Elizabeth", "Sofia", "Avery", "Madison", "Scarlett",
    
    # French names
    "Antoine", "Louis", "Gabriel", "Arthur", "Hugo", "Lucas", "Pierre", "Jean",
    "François", "Nicolas", "Julien", "Maxime", "Alexandre", "Thomas", "Vincent", "Olivier",
    "Marie", "Camille", "Sarah", "Julie", "Manon", "Emma", "Léa", "Chloé",
    "Laura", "Pauline", "Lucie", "Clara", "Alice", "Inès", "Jade", "Lola",
    
    # German names
    "Alexander", "Maximilian", "Paul", "Leon", "Ben", "Jonas", "Noah", "Elias",
    "Finn", "Lucas", "Louis", "Henry", "Felix", "Liam", "David", "Emil",
    "Emma", "Hannah", "Mia", "Sofia", "Lina", "Emilia", "Marie", "Anna",
    "Lea", "Lara", "Amelie", "Lena", "Julia", "Johanna", "Luisa", "Nele",
    
    # Italian names
    "Alessandro", "Francesco", "Andrea", "Matteo", "Lorenzo", "Gabriele", "Mattia", "Davide",
    "Riccardo", "Federico", "Simone", "Filippo", "Marco", "Luca", "Giuseppe", "Antonio",
    "Sofia", "Giulia", "Alice", "Aurora", "Emma", "Giorgia", "Martina", "Greta",
    "Beatrice", "Anna", "Chiara", "Sara", "Nicole", "Francesca", "Arianna", "Alessia",
    
    # Spanish names
    "Alejandro", "Pablo", "Manuel", "Adrián", "Álvaro", "Hugo", "Diego", "Daniel",
    "Carlos", "David", "Mario", "Sergio", "Javier", "Francisco", "Antonio", "Miguel",
    "Lucía", "María", "Martina", "Paula", "Julia", "Daniela", "Carla", "Sofía",
    "Alba", "Claudia", "Andrea", "Valeria", "Carmen", "Elena", "Sara", "Noa"
]

LAST_NAMES = [
    # English surnames
    "Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller", "Davis",
    "Rodriguez", "Martinez", "Hernandez", "Lopez", "Gonzalez", "Wilson", "Anderson", "Thomas",
    "Taylor", "Moore", "Jackson", "Martin", "Lee", "Perez", "Thompson", "White",
    "Harris", "Sanchez", "Clark", "Ramirez", "Lewis", "Robinson", "Walker", "Young",
    
    # French surnames
    "Martin", "Bernard", "Thomas", "Petit", "Robert", "Richard", "Durand", "Dubois",
    "Moreau", "Laurent", "Simon", "Michel", "Lefebvre", "Leroy", "Roux", "David",
    "Bertrand", "Morel", "Fournier", "Girard", "Bonnet", "Dupont", "Lambert", "Fontaine",
    "Rousseau", "Vincent", "Muller", "Lefevre", "Faure", "Andre", "Mercier", "Blanc",
    
    # German surnames
    "Müller", "Schmidt", "Schneider", "Fischer", "Weber", "Meyer", "Wagner", "Becker",
    "Schulz", "Hoffmann", "Schäfer", "Koch", "Bauer", "Richter", "Klein", "Wolf",
    "Schröder", "Neumann", "Schwarz", "Zimmermann", "Braun", "Krüger", "Hofmann", "Hartmann",
    "Lange", "Schmitt", "Werner", "Schmitz", "Krause", "Meier", "Lehmann", "Schmid",
    
    # Italian surnames
    "Rossi", "Russo", "Ferrari", "Esposito", "Bianchi", "Romano", "Colombo", "Ricci",
    "Marino", "Greco", "Bruno", "Gallo", "Conti", "De Luca", "Mancini", "Costa",
    "Giordano", "Rizzo", "Lombardi", "Moretti", "Barbieri", "Fontana", "Santoro", "Mariani",
    "Rinaldi", "Caruso", "Ferrara", "Galli", "Martini", "Leone", "Longo", "Gentile",
    
    # Spanish surnames
    "García", "González", "Rodríguez", "Fernández", "López", "Martínez", "Sánchez", "Pérez",
    "Gómez", "Martín", "Jiménez", "Ruiz", "Hernández", "Díaz", "Moreno", "Muñoz",
    "Álvarez", "Romero", "Alonso", "Gutiérrez", "Navarro", "Torres", "Domínguez", "Vázquez",
    "Ramos", "Gil", "Ramírez", "Serrano", "Blanco", "Suárez", "Molina", "Morales"
]

def generate_random_name():
    """Generate a random foreign name and surname combination"""
    first_name = random.choice(FIRST_NAMES)
    last_name = random.choice(LAST_NAMES)
    return f"{first_name} {last_name}"

def generate_multiple_names(count: int = 10):
    """Generate multiple random names"""
    names = []
    for _ in range(count):
        names.append(generate_random_name())
    return names
