import re
import asyncio
from typing import Optional

# Profanity words list (Turkish)
PROFANITY_WORDS = [
    "amk", "orospu", "oç", "piç", "göt", "sik", "yarrak", "amcık", "kahpe",
    "pezevenk", "ibne", "gavat", "dangalak", "gerizekalı", "salak", "aptal",
    "fuck", "shit", "bitch", "damn", "ass", "dick", "pussy", "whore"
]

# Spam detection patterns
SPAM_PATTERNS = [
    r'(.)\1{5,}',  # Repeated characters (5+ times)
    r'[A-Z]{10,}',  # All caps (10+ characters)
    r'(.{1,10})\1{3,}',  # Repeated phrases
]

# Link patterns
LINK_PATTERNS = [
    r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\\(\\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+',
    r'www\.(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\\(\\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+',
    r'(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\\(\\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+\.(com|org|net|edu|gov|mil|int|co|uk|de|fr|it|es|ru|cn|jp|kr|in|au|ca|br|mx|ar)',
]

async def check_message_content(content: str) -> Optional[str]:
    """Check message content for violations"""
    content_lower = content.lower()
    
    # Check for profanity
    for word in PROFANITY_WORDS:
        if word in content_lower:
            return "küfür içeriği"
    
    # Check for spam patterns
    for pattern in SPAM_PATTERNS:
        if re.search(pattern, content):
            return "spam içeriği"
    
    # Check for links
    for pattern in LINK_PATTERNS:
        if re.search(pattern, content):
            return "link paylaşımı"
    
    return None

def format_duration(seconds: int) -> str:
    """Format duration in seconds to human readable format"""
    if seconds < 60:
        return f"{seconds} saniye"
    elif seconds < 3600:
        minutes = seconds // 60
        return f"{minutes} dakika"
    elif seconds < 86400:
        hours = seconds // 3600
        return f"{hours} saat"
    else:
        days = seconds // 86400
        return f"{days} gün"

def parse_duration(duration_str: str) -> int:
    """Parse duration string to seconds"""
    duration_str = duration_str.lower().strip()
    
    # Extract number and unit
    import re
    match = re.match(r'(\d+)\s*(s|m|h|d|saniye|dakika|saat|gün)?', duration_str)
    
    if not match:
        return 300  # Default 5 minutes
    
    number = int(match.group(1))
    unit = match.group(2) or 'm'
    
    multipliers = {
        's': 1, 'saniye': 1,
        'm': 60, 'dakika': 60,
        'h': 3600, 'saat': 3600,
        'd': 86400, 'gün': 86400
    }
    
    return number * multipliers.get(unit, 60)
